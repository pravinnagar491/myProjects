

  $( document ).ready(function() {
//console.log(dataLisit)
    var dynDiv = "";
     for(var data in dataLisit){
       var name = "";
       var view = "";
       var time = "";
      dynDiv+= '<div class="contentType"><label>'+data+'</label></div><div class="carousel multi-carousel" id="myCarousel'+data+'"><div class="carousel-inner">';
       for(var dataitem in dataLisit[data]){
         name = dataLisit[data][dataitem]['name'];
         view = dataLisit[data][dataitem]['views'];
         time = dataLisit[data][dataitem]['relase_time'];
         //console.log(dataitem);
        if(dataitem == 0){
          dynDiv+= '<div class="item active">';
        }else{
          dynDiv+= '<div class="item">';
        }
        
        dynDiv+='<div class="col-xs-6 col-sm-3 col-md-3 col-lg-3"><a href="#"><img src="'+dataLisit[data][dataitem]['thumbnail']+'" class="img-responsive imgclass"></a>'+
        '<div class="vedioDetails"><p class="tiltelabel">'+name+'</p><span class="timeandview">'+view+' views . '+time+'</span></div></div>'+
      '</div>';
        //dynDiv+= "<span>"+dataLisit[data][dataitem]['thumbnail']+" "+dataLisit[data][dataitem]['name']+"</span>";
       }
       dynDiv+= '</div>'+
        '<a class="left carouselControls" href="#myCarousel'+data+'" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i></a>'+
        '<a class="right carouselControls" href="#myCarousel'+data+'" data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i></a>'+
        '</div>';
     }
     $("#dataContainer").append(dynDiv);



    $('.multi-carousel .item').each(function(){
        var next = $(this).next();
        if (!next.length) {
          next = $(this).siblings(':first');
        }
        next.children(':first-child').clone().appendTo($(this));
        
        for (var i=0;i<2;i++) {
          next=next.next();
          if (!next.length) {
              next = $(this).siblings(':first');
            }
          
          next.children(':first-child').clone().appendTo($(this));
        }
      });


    //console.log(dataLisit);
    responsiveClick();
});

function responsiveClick(){
  if($( window ).width() >= 1024){
    $('#toggle-click').on('click',function(){
      if($(this).attr('data-click-state') == 1) {
          $(this).attr('data-click-state', 0);
          // $(this).css('background-color', 'red')
          desktopscreen();
        }
      else {
        $(this).attr('data-click-state', 1);
        // $(this).css('background-color', 'orange')
        tabScreen();
      }
    });
  }else if($( window ).width() > 767){
    $('#toggle-click').on('click',function(){
      if($(this).attr('data-click-state') == 1) {
          $(this).attr('data-click-state', 0);
          $("#sidebar").css("display","block"); 
        }
      else if($(this).attr('data-click-state') == 0){
        $(this).attr('data-click-state', 1);
        $("#sidebar").css("display","none"); 
      }else{
        $(this).attr('data-click-state', 0);
        $("#sidebar").css("display","block"); 
      }
    });
  }else{
    $('#toggle-click').on('click',function(){
      if($(this).attr('data-click-state') == 1) {
          $(this).attr('data-click-state', 0);
          $("#sidebar").css("display","block"); 
          $("#dataContainer").css("padding","0px 15px");
          $("#sidebar ul").css("padding","0px");
        }
      else if($(this).attr('data-click-state') == 0){
        $(this).attr('data-click-state', 1);
        $("#sidebar").css("display","none"); 
        $("#dataContainer").css("padding","0px 45px");
        $("#sidebar ul").css("padding","24px 0px");
      }else{
        $(this).attr('data-click-state', 0);
        $("#sidebar").css("display","block"); 
        $("#dataContainer").css("padding","0px 15px");
        $("#sidebar ul").css("padding","0px");
      }
    });
  }
}

// $( window ).resize(function() {
//   if($( window ).width() >= 1024){
//     desktopscreen();
//   }else if($( window ).width() > 767){
//     tabScreen();
//   }else{
//     console.log("mobile")
//   }
// });

function desktopscreen(){
  $(".lg-screen").show();
  $("#sidebar ul li span").css("display","inline-block");
  $("#sidebar ul li span").css({"text-align":"left","font-size":"14px"});
  $("#sidebar ul li svg").css("display","inline-block");
  $("#sidebar ul li svg").css("margin","0px 24px 0px 0px"); 
  $("#sidebar, .navbar").css("width","250px"); 
  $(".navbar").css("overflow-y","scroll");
  $("#sidebar").css({"min-width":"250px","max-width":"250px"});
  $("#sidebar ul li").css("padding","7px 21px");
  $("#sidebar ul").css({"position":"relative","top":"0px","width":"100%"});
}

function tabScreen(){
  $(".lg-screen").hide();
  $("#sidebar ul li span").css("display","block");
  $("#sidebar ul li span").css({"text-align":"center","font-size":"10px"});
  $("#sidebar ul li svg").css("display","block");
  $("#sidebar ul li svg").css("margin","0px auto");
  $("#sidebar, .navbar").css("width","75px");
  $(".navbar").css("overflow","hidden");
  $("#sidebar").css({"min-width":"75px","max-width":"75px"});
  $("#sidebar ul li").css("padding","7px 0px");
  $("#sidebar ul").css({"position":"absolute","top":"0px","width":"100%"});
}